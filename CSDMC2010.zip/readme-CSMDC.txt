README


Data hosted and ReadMe file provided by the University of Arizona Artificial Intelligence Lab. Citation information below.

CSDMC2010.zip file contains:
CSDM_API_Train.csv	30 MB
CSDM_API_TestData.csv	33 MB
CSDM_API_TestLable.csv	2 KB
readme_Task3.txt
readme.txt

DESCRIPTION
Knowledge about the malware programs presented in the dataset is outdated and may not contain 
too much information for detecting today�s malware. It may, however, be useful for historical reference or other purposes.

This dataset is composed of a selection of Windows API/System-Call trace files, intended for testing on classifiers treating with sequences. Malware calls are classified and labeled '1' and benign software calls are labeled '0'. The calls are presented in sequential order. CSDM_API_Train.csv contains 388 logs. CSDM_API_TestData.csv contains 378 unclassified logs. CSDM_API_TestLable.csv contains the classifications for CSDM_API_TestData.csv. 
 
For more information, see readme_Task3.txt included with the data.


Date collected: November 2010

Collection method: This data was collected by API monitors during a data mining competition at the International Conference on Neural Information Processing (ICNIP) in Sydney, Austrailia 2010. 


HOW TO CITE THIS DATASET

Author(s): (no author or organization to cite)

Title:  CDMC2010 Malware API Sequence Dataset

Publisher: University of Arizona Artificial Intelligence Lab, AZSecure-data

Location: [AZSecure-data has not yet implemented Digital Object Identifiers or Persistent URLs, please 
copy and paste the location where you retrieve this file from within http://www.azsecure-data.org/]

Publication date: January 2017


IEEE formatted citation:
CSDMC2010 Malware API Sequence Dataset, University of Arizona Artificial Intelligence Lab, AZSecure-data. Available http://www.azsecure-data.org/ [January 2017]











